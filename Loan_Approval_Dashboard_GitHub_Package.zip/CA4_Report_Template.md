# CA4 Capstone Report — Fill-in Template

## 1. Project Title
Personal Loan Application Analytics

## 2. Problem Statement
Financial institutions receive many loan applications and need to understand applicant characteristics and approval patterns. This project explores the approved dataset to summarize application outcomes and compare patterns across relevant applicant and loan variables.

## 3. Business Objectives
- Summarize total, approved, and rejected applications.
- Explore how application outcomes vary across credit score, income, loan amount, product type, and loan purpose.
- Present interactive visualizations and evidence-based recommendations.

## 4. Business Context / Background
Explain why application analytics can help a lending team understand patterns and review its processes. Do not claim that the model predicts creditworthiness unless a predictive model was actually developed.

## 5. Dataset Source
Dataset name: Loan_approval_data_2025.xlsx  
Original public source: [Insert verified source name]  
Source URL: [Insert actual URL]  
Approval/status meaning: [Verify whether 1=Approved and 0=Rejected]

## 6. Dataset Description
The workbook inspected for this starter dashboard contains 50,000 rows and 20 columns. Variables include age, occupation status, annual income, credit score, savings/assets, current debt, product type, loan intent, loan amount, interest rate, ratios, and loan status.

## 7. Data Dictionary
Describe the important columns and their units based on the original dataset documentation. Include customer_id, age, occupation_status, annual_income, credit_score, loan_amount, loan_intent, product_type, and loan_status.

## 8. Data Cleaning and Preparation
In the starter dashboard, column names are stripped of surrounding spaces and exact duplicate rows are removed. In the inspected workbook, no missing cells or exact duplicate rows were found. Re-check these results if the source file changes. Document any additional cleaning actually performed.

## 9. Exploratory Data Analysis
Describe the dataset dimensions, data types, distributions, categories, and relationships that were actually examined.

## 10. Business Questions
- What proportion of applications is approved versus rejected?
- How do credit scores differ between outcome groups?
- How do applications vary by product type and loan purpose?
- What relationship, if any, appears between annual income and loan amount?

## 11. Methodology and Technologies
Explain Python, Pandas, Plotly, Streamlit, GitHub, and the deployment platform. Include the actual code and workflow used.

## 12. Visualizations and Interpretation
Insert screenshots of the dashboard. For every chart, explain what it measures, the observed result from the actual chart, and why the result matters. Avoid inventing findings.

## 13. Key Findings / Business Insights
[Write only findings supported by the displayed data. Add exact values from your final dashboard.]

## 14. Recommendations
Suggest reviewing patterns by credit score, debt-to-income ratio, loan purpose, and product type. Treat these as areas for further investigation, not automatic approval rules. Recommendations must match the results you actually observe.

## 15. Dashboard Link
[Insert deployed Streamlit URL]

## 16. GitHub Repository
[Insert GitHub repository URL]

## 17. Conclusion
Summarize what the dashboard revealed, its limitations, and how the analysis could support further review of lending processes.

## 18. References
List the verified dataset source and any documentation actually used.
