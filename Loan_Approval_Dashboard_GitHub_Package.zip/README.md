# Loan Approval Analysis Dashboard

## Files included
- `app.py` — Streamlit dashboard application
- `requirements.txt` — required Python packages
- `Loan_approval_data_2025.xlsx` — dataset workbook used by this app
- `CA4_Report_Template.md` — report-writing template

## Important before submission
1. Verify the original public source URL for the dataset and add it to your report/README. Do not invent a source.
2. The app currently assumes `loan_status = 1` means Approved and `loan_status = 0` means Rejected. Verify this mapping using the dataset documentation.
3. Check whether the dataset license permits uploading it to a public GitHub repository. If not, do not publish the dataset; use an approved data-access method instead.

## Upload to GitHub
1. Download and extract this ZIP on your computer.
2. Open your GitHub repository.
3. Choose **Add file → Upload files**.
4. Upload `app.py`, `requirements.txt`, and the dataset workbook (only if permitted). `README.md` is also recommended.
5. Click **Commit changes**. The files must be in the repository's top-level folder, not inside another nested folder.
6. In Streamlit Community Cloud, choose this repository, branch `main`, and main file path `app.py`.

## Run locally (optional)
```bash
pip install -r requirements.txt
streamlit run app.py
```
