import os
import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(page_title="Loan Approval Analysis Dashboard", page_icon="📊", layout="wide")

st.markdown("""
<style>
.stApp {background: linear-gradient(135deg, #f4f8ff 0%, #eef6ff 55%, #f8fbff 100%);}
.block-container {padding-top: 1.4rem; padding-bottom: 2rem;}
.hero {background: linear-gradient(100deg,#12315a,#1769aa); padding: 1.35rem 1.5rem; border-radius: 16px; color: white; margin-bottom: 1rem;}
.hero h1 {color:white; margin:0; font-size:2rem;}
.hero p {color:#e5f1ff; margin:.4rem 0 0 0;}
section[data-testid="stSidebar"] {background:#e7f1ff;}
div[data-testid="stMetric"] {background:white; padding:1rem; border-radius:13px; border:1px solid #d9e7f7; box-shadow:0 3px 12px rgba(24,65,112,.07);}
.insight {background:white; border-left:5px solid #2374c6; padding:.8rem 1rem; border-radius:8px; margin:.45rem 0;}
</style>
<div class="hero"><h1>📊 Loan Approval Analysis Dashboard</h1><p>Personal Loan Application Analytics | Business Analytics Capstone</p></div>
""", unsafe_allow_html=True)

DATA_FILE = "Loan_approval_data_2025.xlsx"

@st.cache_data
def load_data(path):
    data = pd.read_excel(path)
    data.columns = data.columns.str.strip()
    return data

if not os.path.exists(DATA_FILE):
    st.error(f"Dataset file not found: {DATA_FILE}. Keep it in the same GitHub repository folder as app.py.")
    st.stop()

df = load_data(DATA_FILE).drop_duplicates().copy()
required = ["loan_status", "annual_income", "credit_score", "loan_amount", "product_type", "loan_intent"]
missing = [c for c in required if c not in df.columns]
if missing:
    st.error("Required dataset columns are missing: " + ", ".join(missing))
    st.stop()

# IMPORTANT: Verify this mapping with the dataset's original documentation before presenting.
# This version assumes 1 = Approved and 0 = Rejected.
if pd.api.types.is_numeric_dtype(df["loan_status"]):
    df["loan_status_label"] = df["loan_status"].map({1: "Approved", 0: "Rejected"}).fillna(df["loan_status"].astype(str))
else:
    df["loan_status_label"] = df["loan_status"].astype(str).str.strip().str.title()

st.sidebar.header("🔎 Dashboard Filters")
filtered = df.copy()
for col, label in [("occupation_status", "Occupation status"), ("product_type", "Loan product"), ("loan_intent", "Loan purpose"), ("loan_status_label", "Loan status")]:
    if col in filtered.columns:
        options = sorted(filtered[col].dropna().astype(str).unique().tolist())
        selected = st.sidebar.multiselect(label, options, default=options)
        filtered = filtered[filtered[col].astype(str).isin(selected)]
if "age" in filtered.columns and not filtered.empty:
    amin, amax = int(filtered["age"].min()), int(filtered["age"].max())
    age_range = st.sidebar.slider("Applicant age", min_value=amin, max_value=amax, value=(amin, amax))
    filtered = filtered[filtered["age"].between(age_range[0], age_range[1])]

st.caption("Use the filters on the left to explore different applicant groups. Metrics and charts update automatically.")
if filtered.empty:
    st.warning("No applications match the selected filters. Change one or more filters.")
    st.stop()

total = len(filtered)
approved = int((filtered["loan_status_label"].str.lower() == "approved").sum())
rejected = int((filtered["loan_status_label"].str.lower() == "rejected").sum())
approval_rate = approved / total * 100 if total else 0
avg_loan = filtered["loan_amount"].mean()
avg_score = filtered["credit_score"].mean()
avg_income = filtered["annual_income"].mean()

k1,k2,k3,k4,k5,k6 = st.columns(6)
k1.metric("Applications", f"{total:,}")
k2.metric("Approved", f"{approved:,}")
k3.metric("Rejected", f"{rejected:,}")
k4.metric("Approval rate", f"{approval_rate:.1f}%")
k5.metric("Average loan", f"{avg_loan:,.0f}")
k6.metric("Average credit score", f"{avg_score:,.0f}")

st.subheader("📈 Application and approval patterns")
left, right = st.columns(2)
with left:
    counts = filtered["loan_status_label"].value_counts().rename_axis("Loan status").reset_index(name="Applications")
    fig = px.pie(counts, names="Loan status", values="Applications", hole=.48, title="Application Outcomes", color="Loan status", color_discrete_map={"Approved":"#22a06b", "Rejected":"#e05252"})
    fig.update_traces(textinfo="percent+label")
    st.plotly_chart(fig, use_container_width=True)
with right:
    prod = filtered.groupby(["product_type", "loan_status_label"]).size().reset_index(name="Applications")
    fig = px.bar(prod, x="product_type", y="Applications", color="loan_status_label", barmode="stack", title="Applications by Loan Product", labels={"product_type":"Loan product", "loan_status_label":"Status"}, color_discrete_map={"Approved":"#22a06b", "Rejected":"#e05252"})
    fig.update_layout(xaxis_tickangle=-15, legend_title_text="Loan status")
    st.plotly_chart(fig, use_container_width=True)
left, right = st.columns(2)
with left:
    purpose = filtered["loan_intent"].value_counts().rename_axis("Loan purpose").reset_index(name="Applications")
    fig = px.bar(purpose, x="Applications", y="Loan purpose", orientation="h", title="Applications by Loan Purpose", color="Applications", color_continuous_scale="Blues")
    st.plotly_chart(fig, use_container_width=True)
with right:
    fig = px.histogram(filtered, x="credit_score", color="loan_status_label", nbins=25, barmode="overlay", opacity=.72, title="Credit Score Distribution by Status", labels={"credit_score":"Credit score", "loan_status_label":"Loan status"}, color_discrete_map={"Approved":"#22a06b", "Rejected":"#e05252"})
    st.plotly_chart(fig, use_container_width=True)
if {"annual_income", "loan_amount"}.issubset(filtered.columns):
    fig = px.scatter(filtered, x="annual_income", y="loan_amount", color="loan_status_label", opacity=.65, title="Annual Income vs Loan Amount", labels={"annual_income":"Annual income", "loan_amount":"Loan amount", "loan_status_label":"Loan status"}, color_discrete_map={"Approved":"#1769aa", "Rejected":"#e05252"}, hover_data=[c for c in ["age", "credit_score", "product_type", "loan_intent"] if c in filtered.columns])
    st.plotly_chart(fig, use_container_width=True)

st.subheader("💡 Business Insights")
most_product = filtered["product_type"].value_counts().idxmax() if not filtered["product_type"].dropna().empty else "Not available"
most_purpose = filtered["loan_intent"].value_counts().idxmax() if not filtered["loan_intent"].dropna().empty else "Not available"
st.markdown(f'<div class="insight">The selected filters contain <b>{total:,}</b> applications, with an approval rate of <b>{approval_rate:.1f}%</b> based on the current status mapping.</div>', unsafe_allow_html=True)
st.markdown(f'<div class="insight">The most common loan product in this selection is <b>{most_product}</b>.</div>', unsafe_allow_html=True)
st.markdown(f'<div class="insight">The most common loan purpose in this selection is <b>{most_purpose}</b>.</div>', unsafe_allow_html=True)
st.markdown(f'<div class="insight">Average annual income is <b>{avg_income:,.0f}</b>, while the average requested loan amount is <b>{avg_loan:,.0f}</b>.</div>', unsafe_allow_html=True)
if approved and rejected:
    a_score = filtered.loc[filtered["loan_status_label"].str.lower()=="approved", "credit_score"].mean()
    r_score = filtered.loc[filtered["loan_status_label"].str.lower()=="rejected", "credit_score"].mean()
    st.markdown(f'<div class="insight">Average credit score: approved group <b>{a_score:,.1f}</b>; rejected group <b>{r_score:,.1f}</b>. This is a descriptive comparison, not proof of causation.</div>', unsafe_allow_html=True)

with st.expander("📋 View filtered application data"):
    st.dataframe(filtered.drop(columns=["loan_status_label"], errors="ignore"), use_container_width=True, height=350)
    st.download_button("Download filtered data as CSV", data=filtered.drop(columns=["loan_status_label"], errors="ignore").to_csv(index=False).encode("utf-8"), file_name="filtered_loan_applications.csv", mime="text/csv")

st.caption("Academic project dashboard. Verify the original dataset source and confirm the meaning of loan_status values before interpreting approval results.")
